Henrik Larsen
Assignment 8 Part 1
How to run: In terminal, type in python Larsen_Assignment8.py typos20.data
After it's done running, it will output a file called Larsen_Assignment8_CPT.txt, which stores all the probabilities.

