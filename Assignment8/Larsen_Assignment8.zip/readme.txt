Henrik Larsen
Assignment 8 Part 2
How to run: In terminal, type in python Larsen_Assignment8.py typos20.data typos20Test.data
After it's done running, it will output a file called Larsen_Assignment8.txt, which stores all the probabilities, the final sequence and the error rates.

